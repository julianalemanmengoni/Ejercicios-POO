# Actividad 06 - Login y Formulario

Este programa muestra un login con `QLineEdit` y `QPushButton`.  
Si el usuario es `admin` y la clave `1111`, se abre un formulario con campos de Legajo, Nombre y Apellido.  
Si la clave es incorrecta, se borra el campo de clave.

## Cómo correr el proyecto

1. Abrí el archivo `.pro` con Qt Creator.
2. Compilá y ejecutá.

El programa muestra una GUI con login.
