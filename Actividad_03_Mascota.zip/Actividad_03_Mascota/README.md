# Actividad 03 - Clase Mascota

Este proyecto crea objetos de la clase `Mascota` hasta consumir aproximadamente 200 MB de RAM.  
La clase incluye atributos simulados para ocupar memoria. Se informa cuántos objetos se crearon.

## Cómo correr el proyecto

1. Abrir el archivo `.pro` con Qt Creator.
2. Compilar y ejecutar.

El programa es solo de consola.
