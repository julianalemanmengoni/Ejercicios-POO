# Actividad 04 - Control de Volumen

Este programa usa un `QSlider` y un `QSpinBox` conectados entre sí.  
Cuando se modifica el valor del slider, el título de la ventana se actualiza con ese valor.

## Cómo correr el proyecto

1. Abrir el archivo `.pro` con Qt Creator.
2. Compilar y ejecutar.

El programa muestra una ventana GUI.
