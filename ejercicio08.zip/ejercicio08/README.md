# Ejercicio 08 - Validación de Usuarios con FastAPI y MySQL

Este proyecto permite validar usuarios mediante un endpoint de FastAPI que consulta una base de datos MySQL.

## Archivos incluidos

- `main.py`: API FastAPI con un endpoint `/auth/login`.
- `usuarios.sql`: script para crear la base de datos y la tabla `usuarios` con datos de ejemplo.
- `requirements.txt`: dependencias necesarias.

## Pasos para ejecutar

1. Crear la base de datos y tabla en MySQL:

```bash
mysql -u root -p < usuarios.sql
```

2. Instalar dependencias:

```bash
pip install -r requirements.txt
```

3. Ejecutar la API:

```bash
uvicorn main:app --reload
```

4. Probar el endpoint (por ejemplo con curl o Postman):

```bash
POST http://localhost:8000/auth/login
{
  "usuario": "ana",
  "clave": "1234"
}
```
