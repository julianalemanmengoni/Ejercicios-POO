# Actividad 01 - Clase Poste

Esta actividad define una clase `Poste` con dos atributos: `altura` (int) y `diámetro` (float).  
Se crean 5 postes, se muestran por consola, se ordenan por altura, y se vuelven a mostrar.

## Cómo correr el proyecto

1. Abrir el archivo `.pro` con Qt Creator.
2. Compilar y ejecutar.

El programa es solo de consola.
