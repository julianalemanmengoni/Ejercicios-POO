# Actividad 02 - Expresiones Idiomáticas

Este programa crea un vector de strings con expresiones idiomáticas, las muestra por consola, y luego las ordena alfabéticamente ignorando los espacios.

## Cómo correr el proyecto

1. Abrir el archivo `.pro` con Qt Creator.
2. Compilar y ejecutar.

El programa es solo de consola.
