# Actividad 05 - Mostrar Imagen en QLabel

Este programa muestra una imagen JPG en un QLabel a pantalla completa sin deformarla.  
Luego de 3 segundos, la aplicación se cierra automáticamente.

## Cómo correr el proyecto

1. Asegurate de tener una imagen llamada `imagen.jpg` en la misma carpeta del proyecto.
2. Abrí el archivo `.pro` con Qt Creator.
3. Compilá y ejecutá.
