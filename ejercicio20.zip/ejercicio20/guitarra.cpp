#include "guitarra.h"
#include <iostream>

void Guitarra::sonar() {
    std::cout << "Guitarra suena..." << std::endl;
}
