#include "teclado.h"
#include <iostream>

void Teclado::sonar() {
    std::cout << "Teclado suena..." << std::endl;
}
