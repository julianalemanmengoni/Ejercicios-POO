#include "bateria.h"
#include <iostream>

void Bateria::sonar() {
    std::cout << "Batería suena..." << std::endl;
}
