#include "persona.h"

int Persona::contador = 0;
